const products = '[{"id":"530","name":"Bamboo Thermal Ski Coat","image_title":"ski-coat_lynda_29940","image":"https://hplussport.com/wp-content/uploads/2016/12/ski-coat_LYNDA_29940.jpg"},{"id":"436","name":"Blueberry Mineral Water","image_title":"mineral-water-blueberry_600px","image":"https://hplussport.com/wp-content/uploads/2015/12/mineral-water-blueberry_600px.png"}]';

// Add code to parse the products variable here:


const item = '{"id":"530","name":"Bamboo Thermal Ski Coat","image_title":"ski-coat_lynda_29940","image":"https://hplussport.com/wp-content/uploads/2016/12/ski-coat_LYNDA_29940.jpg"}';

// Add code to parse the item variable here:

