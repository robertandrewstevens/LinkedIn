const productData = JSON.parse(rawProductData);
console.log(productData);
