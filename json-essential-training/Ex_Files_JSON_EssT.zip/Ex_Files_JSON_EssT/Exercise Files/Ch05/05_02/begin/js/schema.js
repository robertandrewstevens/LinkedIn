// Schema for product data
