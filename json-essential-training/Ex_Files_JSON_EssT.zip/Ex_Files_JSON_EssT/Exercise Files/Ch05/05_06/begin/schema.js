// Schema for weather data
var weatherSchema = {};
