# Swahili News Classification Dataset
Source: https://zindi.africa/competitions/swahili-news-classification/leaderboard