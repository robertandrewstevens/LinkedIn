# AG News Classification Dataset
Source: https://www.kaggle.com/datasets/amananandrai/ag-news-classification-dataset