# Data Science Nigeria 2019 Challenge #1: Insurance Prediction Dataset
Source: https://zindi.africa/competitions/data-science-nigeria-2019-challenge-1-insurance-prediction